
package dao;

/**
 *
 * @author branc
 */
import modelo.ConexionBD;
import modelo.Usuario;
import java.sql.*;

public class UsuarioDAO {

    // Método que busca un usuario con su nombre y contraseña
    public Usuario validarUsuario(String username, String password) {
        Usuario usuario = null; // Guardará el usuario si lo encuentra

        String sql = "SELECT * FROM usuarios WHERE username=? AND password=? AND activo=1";

        try {
            Connection con = ConexionBD.conectar(); // Conexión a la BD
            PreparedStatement ps = con.prepareStatement(sql);
            
            ps.setString(1, username);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                usuario = new Usuario(
                    rs.getInt("id_usuario"),
                    rs.getString("username"),
                    rs.getString("password"),
                    rs.getString("rol"),
                    rs.getBoolean("activo")
                );
            }

            con.close(); // Cerramos conexión
        } catch (Exception e) {
            System.out.println("Error al validar usuario: " + e.getMessage());
        }

        return usuario; // Devuelve null si no se encontró
    }
}