package modelo;
import java.sql.*;

/**
 *
 * @author branc
 */
public class ConexionBD {
    public static Connection conectar() throws SQLException {
        return DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/minimarket_db", //conexion a la base de datos
            "adminMinimarket", //usuario de la db
            "JL0*_dbAdmin10"   //password del usuario
        ); 
    }
}
