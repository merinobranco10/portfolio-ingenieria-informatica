package modelo;

/**
 *
 * @author branc
 */
public class Usuario {
    private int idUsuario;
    private String username;
    private String password;
    private String rol;
    private boolean activo;

    // Constructor vacío
    public Usuario() {}

    // Constructor completo
    public Usuario(int idUsuario, String username, String password, String rol, boolean activo) {
        this.idUsuario = idUsuario;
        this.username = username;
        this.password = password;
        this.rol = rol;
        this.activo = activo;
    }

    // Getters 
    public int getIdUsuario() 
    { return idUsuario; }
    
    public String getUsername() 
    { return username; }
    
    public String getRol() 
    { return rol; }
    
    public boolean isActivo() 
    { return activo; }
 
    // Setters
    public void setIdUsuario(int idUsuario) 
    { this.idUsuario = idUsuario; }
    
    public void setUsername(String username) 
    { this.username = username; }
    
    public void setRol(String rol) 
    { this.rol = rol; }
    
    public void setActivo(boolean activo) 
    { this.activo = activo; }
}