package appminimarket;

/**
 *
 * @author branc
 */
import vista.vistaLogin;

public class Main {
    public static void main(String[] args) {
        // Iniciar la app directamente desde la vista de login
        java.awt.EventQueue.invokeLater(() -> {
            vistaLogin login = new vistaLogin();
            login.setVisible(true);
        });
    }
}
