package modelo;

/**
 *
 * @author branc
 */

public class Producto {
    private int idProducto;
    private String nombre;
    private int idCategoria;
    private String tipoVenta;
    private double precioBase;
    private double stock;
    private String extra;
    
    // Constructor vacio, para crear objeto sin datos inicialmente
    public Producto(){
    }
    
    // Constructor
    public Producto(int idProducto, String nombreProducto, int idCategoria, String tipoVenta,
                    double precioBase, double stock, String extra) {
        this.idProducto = idProducto;
        this.nombre = nombreProducto;
        this.idCategoria = idCategoria;
        this.tipoVenta = tipoVenta;
        this.precioBase = precioBase;
        this.stock = stock;
        this.extra = extra;
    }

    // Getters
    public int getIdProducto() { 
        return idProducto; }
    
    public String getNombre() { 
        return nombre; }
    
    public int getIdCategoria() { 
        return idCategoria; }
    
    public String getTipoVenta() {
        return tipoVenta; }
    
    public double getPrecioBase() { 
        return precioBase; }
    
    public double getStock() { 
        return stock; }
    
    public String getExtra() { 
        return extra; }

    //Setter
    public void setIdProducto(int id)  
    { this.idProducto = id; }
    
    public void setNombre(String nombre) 
    { this.nombre = nombre; }
    
    public void setIdCategoria(int idCategoria) 
    { this.idCategoria = idCategoria; }
    
    public void setTipoVenta(String tipoVenta) 
    { this.tipoVenta = tipoVenta; }
    
    public void setPrecioBase(double precioBase) 
    { this.precioBase = precioBase; }
    
    public void setStock(double stock) 
    { this.stock = stock; }
    
    public void setExtra(String extra) 
    { this.extra = extra; }

    
    // Métodos de Cálculo
    
    //Calcula subtotal
    public double calcularSubtotal(double cantidad) {
        return precioBase * cantidad;
    }
    
    //Calcula IVA (19%)
    public double calcularIVA(double cantidad) {
        return calcularSubtotal(cantidad) * 0.19;
    }
    
    // Calcula el total con IVA incluido
    public double calcularTotal(double cantidad) {
        return calcularSubtotal(cantidad) * 1.19;
    }

    //Metodo para mostrar
    public String mostrarProducto() {
        return nombre + " - $" + precioBase;
    }
}

