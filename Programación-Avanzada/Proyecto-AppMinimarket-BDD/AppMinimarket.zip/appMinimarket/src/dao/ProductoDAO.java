package dao;

/**
 *
 * @author branc
 */

import modelo.ConexionBD;
import modelo.Producto;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

///Esta clase forma parte de la capa DAO (Data Access Object),
public class ProductoDAO {
    // Método que devuelve una lista con todos los productos guardados en la base de datos.
    public List<Producto> listarProductos() {
        // Lista donde se guardarán los productos encontrados
        List<Producto> listaProductos = new ArrayList<>();
        // Consulta SQL
        String consultaSQL = "SELECT * FROM productos";
        try {
            // Conectar con la BD
            Connection conexion = ConexionBD.conectar();
            // Crear un objeto que nos permita ejecutar la consulta
            PreparedStatement consulta = conexion.prepareStatement(consultaSQL);
            // Ejecutar la consulta y guardar los resultados
            ResultSet resultado = consulta.executeQuery();
            // Recorrer cada fila de los resultados
            while (resultado.next()) {
                // Crear un nuevo objeto Producto con los datos de la fila actual
                Producto p = new Producto();
                p.setIdProducto(resultado.getInt("id_producto"));
                p.setNombre(resultado.getString("nombre"));
                p.setIdCategoria(resultado.getInt("id_categoria"));
                p.setTipoVenta(resultado.getString("tipo_venta"));
                p.setPrecioBase(resultado.getDouble("precio_base"));
                p.setStock(resultado.getDouble("stock"));
                p.setExtra(resultado.getString("extra"));
                // Agregar el producto a la lista
                listaProductos.add(p);
            }
            // Cerrar la conexión
            conexion.close();
        } catch (SQLException e) {
            // Si ocurre un error, se muestra un mensaje en la consola
            System.out.println("Error al obtener productos: " + e.getMessage());
        }
        // Devolver la lista con todos los productos encontrados
        return listaProductos;
    }
}
