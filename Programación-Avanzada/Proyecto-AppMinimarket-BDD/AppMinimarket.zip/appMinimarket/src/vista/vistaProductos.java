package vista;

/**
 *
 * @author branc
 */

import dao.ProductoDAO;
import modelo.Producto;
import modelo.Usuario;
import java.util.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class vistaProductos extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(vistaProductos.class.getName());
    
    private final vistaMenu menuAnterior;
    private final Usuario usuario;
    private final ProductoDAO productoDAO = new ProductoDAO();
    private final DefaultTableModel modeloTabla;
    
    public vistaProductos(vistaMenu menu, Usuario u) {
        initComponents();
        this.menuAnterior = menu;
        this.usuario = u;
        this.setTitle("Listado de Productos - Minimarket Don Juan");
        this.setLocationRelativeTo(null);

        modeloTabla = (DefaultTableModel) tablaProductos.getModel();
        cargarCategorias();
        
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

       
    }
    
    private void cargarCategorias() {
        cmbCategoria.removeAllItems();
        cmbCategoria.addItem("Seleccionar categoría...");
        cmbCategoria.addItem("Bebestibles");
        cmbCategoria.addItem("Alimentos");
        cmbCategoria.addItem("Limpieza");
        cmbCategoria.addItem("Snacks");
        cmbCategoria.addItem("Congelados");
        cmbCategoria.addItem("Higiene");
        cmbCategoria.addItem("Abarrotes");
        cmbCategoria.addItem("Otros");
    }
    
    private void mostrarProductosPorNombreCategoria(String nombreCategoria) {
        List<Producto> lista = productoDAO.listarProductos();
        modeloTabla.setRowCount(0);

        int idCategoria = 0;

        switch (nombreCategoria) {
            case "Bebestibles": idCategoria = 1; break;
            case "Alimentos": idCategoria = 2; break;
            case "Limpieza": idCategoria = 3; break;
            case "Snacks": idCategoria = 4; break;
            case "Congelados": idCategoria = 5; break;
            case "Higiene": idCategoria = 6; break;
            case "Abarrotes": idCategoria = 7; break;
            case "Otros": idCategoria = 8; break;
        }

        for (Producto p : lista) {
            if (p.getIdCategoria() == idCategoria) {
                modeloTabla.addRow(new Object[]{
                    p.getIdProducto(),
                    p.getNombre(),
                    p.getTipoVenta(),
                    p.getPrecioBase(),
                    p.getStock()
                });
            }
        }

        if (modeloTabla.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "No hay productos en la categoría seleccionada");
        }
    }
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        lblCategoria = new javax.swing.JLabel();
        cmbCategoria = new javax.swing.JComboBox<>();
        btnMostrar = new javax.swing.JButton();
        btnVolver = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaProductos = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lblCategoria.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lblCategoria.setText("Categoría:");

        cmbCategoria.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        cmbCategoria.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        btnMostrar.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        btnMostrar.setText("Mostrar");
        btnMostrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarActionPerformed(evt);
            }
        });

        btnVolver.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        btnVolver.setText("Volver");
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });

        tablaProductos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "Nombre", "Tipo Venta", "Precio", "Stock"
            }
        ));
        jScrollPane1.setViewportView(tablaProductos);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 703, Short.MAX_VALUE)
                        .addGap(237, 237, 237)
                        .addComponent(btnVolver)
                        .addGap(26, 26, 26))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblCategoria)
                        .addGap(18, 18, 18)
                        .addComponent(cmbCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(29, 29, 29)
                        .addComponent(btnMostrar)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnVolver)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblCategoria)
                            .addComponent(cmbCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnMostrar))
                        .addGap(9, 9, 9)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 675, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnMostrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarActionPerformed
        if (cmbCategoria.getSelectedIndex() <= 0) {
            JOptionPane.showMessageDialog(this, "Selecciona una categoría");
            return;
        }

        String nombreCategoria = cmbCategoria.getSelectedItem().toString();
        mostrarProductosPorNombreCategoria(nombreCategoria);
    }//GEN-LAST:event_btnMostrarActionPerformed

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
        menuAnterior.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnVolverActionPerformed

    /**
     * @param args the command line arguments
     */

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnMostrar;
    private javax.swing.JButton btnVolver;
    private javax.swing.JComboBox<String> cmbCategoria;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblCategoria;
    private javax.swing.JTable tablaProductos;
    // End of variables declaration//GEN-END:variables
}
