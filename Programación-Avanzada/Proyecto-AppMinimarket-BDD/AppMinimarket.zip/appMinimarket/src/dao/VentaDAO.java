package dao;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
import java.util.List;
import modelo.ConexionBD;
import modelo.Producto;
import java.sql.PreparedStatement;


/**
 *
 * @author branc
 */
public class VentaDAO {

    // Inserta una venta completa: cabecera + detalles
    public boolean registrarVenta(double subtotal, double iva, double total, int idUsuario, 
                              List<Producto> productos, List<Double> cantidades) {
    String sqlVenta = "INSERT INTO ventas (subtotal, iva, total_final, id_usuario, fecha) VALUES (?, ?, ?, ?, NOW())";
    String sqlDetalle = "INSERT INTO detalle_venta (id_venta, id_producto, cantidad, precio_unitario, subtotal) VALUES (?, ?, ?, ?, ?)";
    String sqlActualizarStock = "UPDATE productos SET stock = stock - ? WHERE id_producto = ?";

    try (Connection conn = ConexionBD.conectar()) {
        conn.setAutoCommit(false);

        // Registrar Venta
        PreparedStatement psVenta = conn.prepareStatement(sqlVenta, Statement.RETURN_GENERATED_KEYS);
        psVenta.setDouble(1, subtotal);
        psVenta.setDouble(2, iva);
        psVenta.setDouble(3, total);
        psVenta.setInt(4, idUsuario);
        psVenta.executeUpdate();

        ResultSet rs = psVenta.getGeneratedKeys();
        int idVenta = 0;
        if (rs.next()) {
            idVenta = rs.getInt(1);
        }

        // Registrar detalle y actualizar stock
        PreparedStatement psDetalle = conn.prepareStatement(sqlDetalle);
        PreparedStatement psStock = conn.prepareStatement(sqlActualizarStock);

        for (int i = 0; i < productos.size(); i++) {
            Producto p = productos.get(i);
            double cant = cantidades.get(i);

            psDetalle.setInt(1, idVenta);
            psDetalle.setInt(2, p.getIdProducto());
            psDetalle.setDouble(3, cant);
            psDetalle.setDouble(4, p.getPrecioBase());
            psDetalle.setDouble(5, p.getPrecioBase() * cant);
            psDetalle.addBatch();

            // Actualizar stock
            psStock.setDouble(1, cant);
            psStock.setInt(2, p.getIdProducto());
            psStock.addBatch();
        }

            psDetalle.executeBatch();
            psStock.executeBatch();

            conn.commit();
            return true;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    
    public void mostrarVentas(JTable tabla) {
        String sql = "SELECT * FROM vista_reporte_ventas";
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("ID Venta");
        modelo.addColumn("Fecha");
        modelo.addColumn("Usuario");
        modelo.addColumn("Subtotal");
        modelo.addColumn("IVA");
        modelo.addColumn("Total");

        try (Connection con = ConexionBD.conectar();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                modelo.addRow(new Object[]{
                    rs.getInt("id_venta"),
                    rs.getString("fecha"),
                    rs.getString("usuario"),
                    rs.getDouble("subtotal"),
                    rs.getDouble("iva"),
                    rs.getDouble("total_final")
                });
            }

            tabla.setModel(modelo);

        } catch (SQLException e) {
            System.out.println("Error al mostrar ventas: " + e.getMessage());
        }
    }
}
