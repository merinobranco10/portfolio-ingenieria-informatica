Crear Usuario en BBDD con privilegios en caso de error de conexión:
user: adminMinimarket
password: JL0*_dbAdmin10