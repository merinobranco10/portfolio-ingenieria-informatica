-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 29-10-2025 a las 02:53:11
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `minimarket_db`
--
CREATE DATABASE IF NOT EXISTS `minimarket_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `minimarket_db`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

DROP TABLE IF EXISTS `categorias`;
CREATE TABLE `categorias` (
  `id_categoria` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`id_categoria`, `nombre`) VALUES
(7, 'Abarrotes'),
(2, 'Alimentos'),
(1, 'Bebidas'),
(5, 'Congelados'),
(6, 'Higiene'),
(3, 'Limpieza'),
(8, 'Otros'),
(4, 'Snacks');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_venta`
--

DROP TABLE IF EXISTS `detalle_venta`;
CREATE TABLE `detalle_venta` (
  `id_detalle` int(11) NOT NULL,
  `id_venta` int(11) NOT NULL,
  `id_producto` int(11) NOT NULL,
  `cantidad` decimal(10,3) NOT NULL CHECK (`cantidad` > 0),
  `precio_unitario` decimal(10,2) NOT NULL CHECK (`precio_unitario` >= 0),
  `subtotal` decimal(12,2) NOT NULL CHECK (`subtotal` >= 0),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `detalle_venta`
--

INSERT INTO `detalle_venta` (`id_detalle`, `id_venta`, `id_producto`, `cantidad`, `precio_unitario`, `subtotal`, `created_at`) VALUES
(1, 1, 1, 1.000, 850.00, 850.00, '2025-10-27 20:27:07'),
(2, 1, 3, 3.000, 1000.00, 3000.00, '2025-10-27 20:27:07'),
(3, 2, 1, 8.000, 850.00, 6800.00, '2025-10-27 21:13:47'),
(4, 2, 3, 1.000, 1000.00, 1000.00, '2025-10-27 21:13:47'),
(5, 3, 1, 1.000, 850.00, 850.00, '2025-10-27 22:14:23');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

DROP TABLE IF EXISTS `productos`;
CREATE TABLE `productos` (
  `id_producto` int(11) NOT NULL,
  `nombre` varchar(120) NOT NULL,
  `id_categoria` int(11) NOT NULL,
  `tipo_venta` enum('UNIDAD','KILO') NOT NULL,
  `precio_base` decimal(10,2) NOT NULL CHECK (`precio_base` >= 0),
  `stock` decimal(10,3) NOT NULL DEFAULT 0.000 CHECK (`stock` >= 0),
  `extra` varchar(80) DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id_producto`, `nombre`, `id_categoria`, `tipo_venta`, `precio_base`, `stock`, `extra`, `activo`, `created_at`, `updated_at`) VALUES
(1, 'Coca-Cola 350ml', 1, 'UNIDAD', 850.00, 110.000, 'Botella desechable', 1, '2025-10-27 01:16:45', '2025-10-27 22:14:23'),
(2, 'Pepsi 1.5L', 1, 'UNIDAD', 1700.00, 80.000, 'Botella plástica', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(3, 'Sprite 500ml', 1, 'UNIDAD', 1000.00, 86.000, 'Botella', 1, '2025-10-27 01:16:45', '2025-10-27 21:13:47'),
(4, 'Fanta 1.5L', 1, 'UNIDAD', 1700.00, 70.000, 'Botella plástica', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(5, 'Agua Benedictino 1.6L', 1, 'UNIDAD', 1300.00, 100.000, 'Sin gas', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(6, 'Agua Vital 500ml', 1, 'UNIDAD', 800.00, 100.000, 'Sin gas', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(7, 'Cerveza Cristal 355ml', 1, 'UNIDAD', 1300.00, 90.000, 'Lata', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(8, 'Cerveza Escudo 355ml', 1, 'UNIDAD', 1400.00, 85.000, 'Lata', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(9, 'Cerveza Heineken 500ml', 1, 'UNIDAD', 1900.00, 60.000, 'Lata importada', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(10, 'Néctar Watts Durazno 1L', 1, 'UNIDAD', 1700.00, 75.000, 'Caja', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(11, 'Jugo Andina Naranja 1L', 1, 'UNIDAD', 1500.00, 80.000, 'TetraPak', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(12, 'Red Bull 250ml', 1, 'UNIDAD', 2500.00, 40.000, 'Energética', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(13, 'Monster Energy 500ml', 1, 'UNIDAD', 2800.00, 35.000, 'Energética', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(14, 'Té frío Lipton Limón 1.5L', 1, 'UNIDAD', 1700.00, 60.000, 'Botella', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(15, 'Café instantáneo Nescafé 170g', 1, 'UNIDAD', 6200.00, 25.000, 'Frasco vidrio', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(16, 'Leche Soprole Entera 1L', 1, 'UNIDAD', 1600.00, 100.000, 'Caja TetraPak', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(17, 'Leche Colún Descremada 1L', 1, 'UNIDAD', 1600.00, 90.000, 'Caja TetraPak', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(18, 'Bebida Bilz 2L', 1, 'UNIDAD', 1900.00, 50.000, 'Botella plástica', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(19, 'Bebida Pap 2L', 1, 'UNIDAD', 1900.00, 50.000, 'Botella plástica', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(20, 'Jugo Natural Watt’s 300ml', 1, 'UNIDAD', 900.00, 90.000, 'Botella pequeña', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(21, 'Pan Corriente', 2, 'KILO', 1700.00, 60.000, 'Panadería', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(22, 'Pan Frica', 2, 'KILO', 1800.00, 40.000, 'Panadería', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(23, 'Pan Marraqueta', 2, 'KILO', 1600.00, 50.000, 'Panadería', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(24, 'Queso Gauda Colún', 2, 'KILO', 8500.00, 25.000, 'Refrigerado', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(25, 'Jamón de Pierna San Jorge', 2, 'KILO', 8900.00, 25.000, 'Refrigerado', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(26, 'Arroz Tucapel 1kg', 2, 'UNIDAD', 1900.00, 60.000, 'Grano largo', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(27, 'Azúcar Iansa 1kg', 2, 'UNIDAD', 1700.00, 70.000, 'Blanca granulada', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(28, 'Fideos Carozzi Spaghetti 400g', 2, 'UNIDAD', 1200.00, 80.000, 'Pasta italiana', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(29, 'Aceite Chef 1L', 2, 'UNIDAD', 2900.00, 60.000, 'Vegetal', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(30, 'Sal Lobos 1kg', 2, 'UNIDAD', 1200.00, 70.000, 'Yodada', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(31, 'Harina Selecta 1kg', 2, 'UNIDAD', 1400.00, 60.000, 'Todo uso', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(32, 'Lentejas Lucchetti 1kg', 2, 'UNIDAD', 2500.00, 40.000, 'Legumbre seca', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(33, 'Porotos Hallados 1kg', 2, 'UNIDAD', 2600.00, 40.000, 'Legumbre seca', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(34, 'Levadura instantánea 100g', 2, 'UNIDAD', 1000.00, 25.000, 'Panificación', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(35, 'Leche condensada Nestlé 397g', 2, 'UNIDAD', 2800.00, 35.000, 'Lata', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(36, 'Cereal Chocapic 500g', 2, 'UNIDAD', 4900.00, 25.000, 'Caja', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(37, 'Mantequilla Soprole 125g', 2, 'UNIDAD', 1800.00, 40.000, 'Refrigerado', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(38, 'Margarina Dorina 250g', 2, 'UNIDAD', 1700.00, 40.000, 'Refrigerado', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(39, 'Huevos Granja 12 unidades', 2, 'UNIDAD', 4200.00, 40.000, 'Docena', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(40, 'Yoghurt Colún 1L', 2, 'UNIDAD', 2200.00, 60.000, 'Refrigerado', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(41, 'Detergente Ariel 1kg', 3, 'UNIDAD', 4500.00, 40.000, 'Polvo', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(42, 'Detergente OMO Líquido 3L', 3, 'UNIDAD', 8900.00, 30.000, 'Botella', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(43, 'Cloro Clorinda 1L', 3, 'UNIDAD', 1300.00, 50.000, 'Desinfectante', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(44, 'Limpiador Poett Lavanda 900ml', 3, 'UNIDAD', 1800.00, 50.000, 'Aromatizante', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(45, 'Esponja Virutex 2 unidades', 3, 'UNIDAD', 900.00, 40.000, 'Cocina', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(46, 'Guantes de limpieza Virutex', 3, 'UNIDAD', 1800.00, 30.000, 'Talla M', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(47, 'Trapo Absorbente', 3, 'UNIDAD', 800.00, 40.000, 'Multiuso', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(48, 'Lavaloza Quix Limón 750ml', 3, 'UNIDAD', 2300.00, 40.000, 'Botella', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(49, 'Papel Higiénico Elite 4 unidades', 3, 'UNIDAD', 2800.00, 50.000, 'Doble hoja', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(50, 'Toalla Nova 2 unidades', 3, 'UNIDAD', 2300.00, 50.000, 'Cocina', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(51, 'Galletas Tritón 126g', 4, 'UNIDAD', 1000.00, 60.000, 'Sabor vainilla', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(52, 'Galletas Oreo 108g', 4, 'UNIDAD', 1200.00, 60.000, 'Original', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(53, 'Ramitas Evercrisp 90g', 4, 'UNIDAD', 1500.00, 70.000, 'Saladas', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(54, 'Papas Fritas Lays 90g', 4, 'UNIDAD', 1800.00, 70.000, 'Clásicas', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(55, 'Cheetos Queso 95g', 4, 'UNIDAD', 1700.00, 60.000, 'Snack frito', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(56, 'Super 8', 4, 'UNIDAD', 800.00, 120.000, 'Barra individual', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(57, 'Sublime', 4, 'UNIDAD', 1000.00, 100.000, 'Chocolate peruano', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(58, 'Chocolate Sahne-Nuss 90g', 4, 'UNIDAD', 2500.00, 40.000, 'Nestlé', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(59, 'Chicles Trident Menta', 4, 'UNIDAD', 1200.00, 80.000, 'Caja', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(60, 'Caramelos Ambrosoli Mix', 4, 'UNIDAD', 1500.00, 60.000, 'Bolsa', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(61, 'Helado Savory 1L', 5, 'UNIDAD', 5000.00, 30.000, 'Vainilla', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(62, 'Helado San Francisco 1L', 5, 'UNIDAD', 5500.00, 25.000, 'Chocolate', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(63, 'Empanadas de Queso 12 unid.', 5, 'UNIDAD', 6000.00, 20.000, 'Caja congelada', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(64, 'Papas Fritas congeladas McCain 1kg', 5, 'UNIDAD', 4200.00, 40.000, 'Bolsa', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(65, 'Pizza Fría San Jorge', 5, 'UNIDAD', 7000.00, 15.000, 'Listo para hornear', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(66, 'Hamburguesas Veggie NotCo 2un', 5, 'UNIDAD', 4800.00, 25.000, 'Caja', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(67, 'Nuggets San Jorge 500g', 5, 'UNIDAD', 4800.00, 30.000, 'Pollo empanado', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(68, 'Hielo bolsa 2kg', 5, 'UNIDAD', 1200.00, 50.000, 'Bolsa de cubos', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(69, 'Choclos congelados 1kg', 5, 'UNIDAD', 3500.00, 40.000, 'Bolsa', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(70, 'Arvejas congeladas 1kg', 5, 'UNIDAD', 3400.00, 40.000, 'Bolsa', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(71, 'Shampoo Sedal 400ml', 6, 'UNIDAD', 3300.00, 40.000, 'Cabello normal', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(72, 'Acondicionador Pantene 400ml', 6, 'UNIDAD', 3800.00, 40.000, 'Brillo extremo', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(73, 'Pasta Dental Colgate 90g', 6, 'UNIDAD', 1800.00, 50.000, 'Triple acción', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(74, 'Cepillo Dental Oral-B', 6, 'UNIDAD', 2500.00, 30.000, 'Medio', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(75, 'Desodorante Rexona Men', 6, 'UNIDAD', 3500.00, 35.000, 'Spray', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(76, 'Desodorante Dove Women', 6, 'UNIDAD', 3500.00, 35.000, 'Spray', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(77, 'Jabón Dove 90g', 6, 'UNIDAD', 1600.00, 60.000, 'Hidratante', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(78, 'Toallas femeninas Kotex 8un', 6, 'UNIDAD', 3200.00, 30.000, 'Día', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(79, 'Pañales Huggies Talla M 20un', 6, 'UNIDAD', 6800.00, 20.000, 'Bebé', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(80, 'Afeitadora Gillette 2un', 6, 'UNIDAD', 4200.00, 25.000, 'Desechable', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(81, 'Atún San José 170g', 7, 'UNIDAD', 1800.00, 40.000, 'En agua', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(82, 'Salsa de Tomate Carozzi 200g', 7, 'UNIDAD', 1300.00, 40.000, 'Doypack', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(83, 'Mayonesa Hellmann’s 200g', 7, 'UNIDAD', 1700.00, 40.000, 'Doypack', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(84, 'Ketchup Hellmann’s 200g', 7, 'UNIDAD', 1600.00, 40.000, 'Doypack', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(85, 'Mostaza Carozzi 200g', 7, 'UNIDAD', 1600.00, 40.000, 'Doypack', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(86, 'Aceitunas Serrano 250g', 7, 'UNIDAD', 3500.00, 25.000, 'Verdes', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(87, 'Vinagre Capel 1L', 7, 'UNIDAD', 1900.00, 40.000, 'Blanco', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(88, 'Avena Quaker 800g', 7, 'UNIDAD', 3600.00, 30.000, 'Natural', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(89, 'Chocolate en Polvo Milo 400g', 7, 'UNIDAD', 4500.00, 25.000, 'Energético', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(90, 'Mermelada Watt’s Frutilla 500g', 7, 'UNIDAD', 3200.00, 30.000, 'Frasco vidrio', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(91, 'Pilas Duracell AA 2un', 8, 'UNIDAD', 3200.00, 40.000, 'Alcalinas', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(92, 'Encendedor Bic Mini', 8, 'UNIDAD', 900.00, 50.000, 'Colores varios', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(93, 'Fósforos Fragata', 8, 'UNIDAD', 800.00, 50.000, 'Caja', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(94, 'Bolsa de Basura 10un', 8, 'UNIDAD', 1300.00, 40.000, 'Grande', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(95, 'Carbón 2kg', 8, 'UNIDAD', 2800.00, 30.000, 'Asados', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(96, 'Velas 6 unidades', 8, 'UNIDAD', 1000.00, 40.000, 'Blancas', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(97, 'Servilletas Elite 100un', 8, 'UNIDAD', 2100.00, 40.000, 'Papel blanco', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(98, 'Tenedor plástico pack 20un', 8, 'UNIDAD', 1500.00, 30.000, 'Desechable', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(99, 'Cuchillo plástico pack 20un', 8, 'UNIDAD', 1500.00, 30.000, 'Desechable', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(100, 'Cucharas plásticas pack 20un', 8, 'UNIDAD', 1500.00, 30.000, 'Desechable', 1, '2025-10-27 01:16:45', '2025-10-27 01:16:45'),
(101, 'Tomate Cherry 250g', 2, 'UNIDAD', 1900.00, 40.000, 'Bandeja fresca', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(102, 'Lechuga Escarola', 2, 'UNIDAD', 1200.00, 50.000, 'Fresca', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(103, 'Lechuga Romana', 2, 'UNIDAD', 1300.00, 45.000, 'Fresca', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(104, 'Espinaca Fresca 250g', 2, 'UNIDAD', 1500.00, 40.000, 'Bolsa', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(105, 'Zanahoria 1kg', 2, 'KILO', 1200.00, 70.000, 'Granel', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(106, 'Betarraga 1kg', 2, 'KILO', 1300.00, 60.000, 'Granel', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(107, 'Repollo Morado', 2, 'UNIDAD', 1400.00, 35.000, 'Fresca', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(108, 'Brócoli 500g', 2, 'UNIDAD', 1900.00, 40.000, 'Bolsa', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(109, 'Coliflor', 2, 'UNIDAD', 1800.00, 35.000, 'Entera', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(110, 'Papa Nueva 1kg', 2, 'KILO', 1500.00, 80.000, 'Granel', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(111, 'Cebolla Morada 1kg', 2, 'KILO', 1400.00, 60.000, 'Granel', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(112, 'Ajo 250g', 2, 'UNIDAD', 1200.00, 50.000, 'Malla', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(113, 'Pimentón Rojo', 2, 'UNIDAD', 1000.00, 80.000, 'Unidad', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(114, 'Pimentón Verde', 2, 'UNIDAD', 900.00, 80.000, 'Unidad', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(115, 'Zapallo Italiano 1kg', 2, 'KILO', 1800.00, 50.000, 'Granel', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(116, 'Choclo Entero', 2, 'UNIDAD', 1000.00, 70.000, 'Fresco', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(117, 'Palta Hass 1kg', 2, 'KILO', 5200.00, 40.000, 'Granel', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(118, 'Plátano 1kg', 2, 'KILO', 1500.00, 90.000, 'Importado', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(119, 'Manzana Roja 1kg', 2, 'KILO', 1700.00, 90.000, 'Fruta nacional', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(120, 'Manzana Verde 1kg', 2, 'KILO', 1800.00, 80.000, 'Fruta nacional', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(121, 'Naranja 1kg', 2, 'KILO', 1500.00, 85.000, 'Fruta nacional', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(122, 'Limón 1kg', 2, 'KILO', 2000.00, 60.000, 'Fresco', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(123, 'Durazno 1kg', 2, 'KILO', 2500.00, 50.000, 'De temporada', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(124, 'Uva Red Globe 1kg', 2, 'KILO', 2700.00, 45.000, 'Fresca', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(125, 'Sandía Entera', 2, 'UNIDAD', 6000.00, 20.000, 'Grande', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(126, 'Melón Calameño', 2, 'UNIDAD', 5500.00, 25.000, 'De estación', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(127, 'Pera Packham 1kg', 2, 'KILO', 1800.00, 70.000, 'Fruta', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(128, 'Kiwi 1kg', 2, 'KILO', 2000.00, 60.000, 'Fruta', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(129, 'Mandarina 1kg', 2, 'KILO', 1600.00, 70.000, 'Fruta nacional', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(130, 'Piña Entera', 2, 'UNIDAD', 3500.00, 30.000, 'Tropical', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(131, 'Pollo Entero', 2, 'KILO', 2900.00, 40.000, 'Fresco', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(132, 'Pechuga de Pollo', 2, 'KILO', 5800.00, 30.000, 'Fileteada', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(133, 'Truto Corto', 2, 'KILO', 4800.00, 35.000, 'Refrigerado', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(134, 'Posta Negra Vacuno', 2, 'KILO', 8900.00, 25.000, 'Corte tradicional', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(135, 'Lomo Vetado Vacuno', 2, 'KILO', 12900.00, 20.000, 'Premium', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(136, 'Chuleta de Cerdo', 2, 'KILO', 7500.00, 25.000, 'Refrigerado', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(137, 'Costillar de Cerdo', 2, 'KILO', 7800.00, 20.000, 'Marinado', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(138, 'Longaniza San Jorge 500g', 2, 'UNIDAD', 4800.00, 30.000, 'Embutido', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(139, 'Vienesas Llanquihue 6un', 2, 'UNIDAD', 2800.00, 35.000, 'Paquete', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(140, 'Salmón Filete 1kg', 2, 'KILO', 14200.00, 15.000, 'Fresco', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(141, 'Merluza Filete 1kg', 2, 'KILO', 7500.00, 20.000, 'Fresca', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(142, 'Reineta Filete 1kg', 2, 'KILO', 8200.00, 20.000, 'Fresca', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(143, 'Jurel en Lata San José 425g', 2, 'UNIDAD', 2300.00, 40.000, 'En aceite', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(144, 'Atún Lomitos Robinson Crusoe 170g', 2, 'UNIDAD', 2100.00, 50.000, 'En agua', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(145, 'Leche Deslactosada Colún 1L', 2, 'UNIDAD', 1700.00, 80.000, 'Caja TetraPak', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(146, 'Yoghurt Soprole Natural 1L', 2, 'UNIDAD', 2200.00, 70.000, 'Botella', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(147, 'Quesillo 500g', 2, 'UNIDAD', 3800.00, 30.000, 'Refrigerado', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(148, 'Queso Fresco 1kg', 2, 'KILO', 7200.00, 25.000, 'Refrigerado', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(149, 'Mantequilla Colún 125g', 2, 'UNIDAD', 1900.00, 40.000, 'Refrigerado', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(150, 'Crema de Leche Soprole 200ml', 2, 'UNIDAD', 1600.00, 50.000, 'Caja', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(151, 'Flan Savory Vainilla 100g', 2, 'UNIDAD', 1000.00, 40.000, 'Postre instantáneo', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(152, 'Gelatina Frambuesa 100g', 2, 'UNIDAD', 900.00, 50.000, 'Polvo', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(153, 'Garbanzos Lucchetti 1kg', 7, 'UNIDAD', 2500.00, 50.000, 'Legumbre seca', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(154, 'Porotos Negros 1kg', 7, 'UNIDAD', 2600.00, 50.000, 'Legumbre seca', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(155, 'Cereal Zucaritas 500g', 7, 'UNIDAD', 4800.00, 30.000, 'Caja', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(156, 'Avena Quaker Instantánea 500g', 7, 'UNIDAD', 2500.00, 40.000, 'Natural', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(157, 'Miel Natural 500g', 7, 'UNIDAD', 4800.00, 20.000, 'Frasco', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(158, 'Chocolate Costa 90g', 7, 'UNIDAD', 2500.00, 30.000, 'Chocolate negro', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(159, 'Cacao en Polvo Ideal 400g', 7, 'UNIDAD', 4400.00, 25.000, 'Instantáneo', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(160, 'Vinagre de Manzana Capel 1L', 7, 'UNIDAD', 1900.00, 40.000, 'Natural', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(161, 'Mostaza Gourmet 200g', 7, 'UNIDAD', 1700.00, 30.000, 'Doypack', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(162, 'Mayonesa Arcor 200g', 7, 'UNIDAD', 1600.00, 40.000, 'Doypack', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(163, 'Galletas Costa Frac 126g', 4, 'UNIDAD', 1100.00, 60.000, 'Chocolate', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(164, 'Chocman Mini 25g', 4, 'UNIDAD', 700.00, 120.000, 'Individual', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(165, 'Ramitas BBQ Evercrisp 90g', 4, 'UNIDAD', 1600.00, 70.000, 'Sabor BBQ', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(166, 'Doritos Queso 90g', 4, 'UNIDAD', 1700.00, 80.000, 'Snack frito', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(167, 'Gomitas Frutales Ambrosoli 90g', 4, 'UNIDAD', 1300.00, 60.000, 'Bolsa', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(168, 'Chocolate Sahne-Nuss Blanco 90g', 4, 'UNIDAD', 2600.00, 40.000, 'Nestlé', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(169, 'Super 8 XL', 4, 'UNIDAD', 1200.00, 100.000, 'Barra grande', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(170, 'Galletas Rellenas Toddy 120g', 4, 'UNIDAD', 1300.00, 70.000, 'Sabor chocolate', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(171, 'Papas Fritas Ruffles 90g', 4, 'UNIDAD', 1800.00, 60.000, 'Clásicas', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(172, 'Cereal Bar Fitness 23g', 4, 'UNIDAD', 900.00, 80.000, 'Individual', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(173, 'Empanadas de Marisco 6un', 5, 'UNIDAD', 6400.00, 20.000, 'Congeladas', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(174, 'Croquetas de Pollo 500g', 5, 'UNIDAD', 4700.00, 30.000, 'Listas para freír', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(175, 'Verduras Mixtas Congeladas 1kg', 5, 'UNIDAD', 3800.00, 40.000, 'Bolsa', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(176, 'Espinaca Congelada 1kg', 5, 'UNIDAD', 3600.00, 40.000, 'Bolsa', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(177, 'Pizza Individual San Jorge', 5, 'UNIDAD', 4200.00, 30.000, 'Congelada', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(178, 'Hamburguesas de Pollo 4un', 5, 'UNIDAD', 4300.00, 30.000, 'Caja', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(179, 'Filete de Pescado Apanado 500g', 5, 'UNIDAD', 4600.00, 25.000, 'Caja', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(180, 'Pan de Ajo Congelado 4un', 5, 'UNIDAD', 3200.00, 35.000, 'Listo para horno', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(181, 'Helado Savory Chocolate 1L', 5, 'UNIDAD', 5200.00, 25.000, 'Postre', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(182, 'Helado Frutilla Savory 1L', 5, 'UNIDAD', 5200.00, 25.000, 'Postre', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(183, 'Pan Integral 1kg', 2, 'KILO', 2000.00, 50.000, 'Panadería', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(184, 'Pan Ciabatta', 2, 'UNIDAD', 900.00, 70.000, 'Panadería', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(185, 'Pan Baguette', 2, 'UNIDAD', 1100.00, 60.000, 'Panadería', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(186, 'Kuchen Frambuesa', 2, 'UNIDAD', 3500.00, 20.000, 'Pastelería', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(187, 'Queque de Vainilla', 2, 'UNIDAD', 2800.00, 25.000, 'Pastelería', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(188, 'Brownie de Chocolate', 2, 'UNIDAD', 2600.00, 30.000, 'Repostería', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(189, 'Empanada de Pino', 2, 'UNIDAD', 2200.00, 40.000, 'Horneada', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(190, 'Empanada de Queso', 2, 'UNIDAD', 2300.00, 40.000, 'Horneada', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(191, 'Croissant Mantequilla', 2, 'UNIDAD', 1700.00, 40.000, 'Repostería', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(192, 'Berlines con crema', 2, 'UNIDAD', 1800.00, 35.000, 'Pastelería', 1, '2025-10-27 01:19:48', '2025-10-27 01:19:48'),
(193, 'Tocino Ahumado 250g', 2, 'UNIDAD', 3900.00, 30.000, 'Refrigerado', 1, '2025-10-27 01:20:12', '2025-10-27 01:20:12'),
(194, 'Hamburguesa de Vacuno 4un', 5, 'UNIDAD', 5200.00, 25.000, 'Caja congelada', 1, '2025-10-27 01:20:12', '2025-10-27 01:20:12'),
(195, 'Queso Parmesano Rallado 100g', 2, 'UNIDAD', 2500.00, 40.000, 'Paquete sellado', 1, '2025-10-27 01:20:12', '2025-10-27 01:20:12'),
(196, 'Mermelada de Durazno Watt’s 500g', 7, 'UNIDAD', 3200.00, 35.000, 'Frasco vidrio', 1, '2025-10-27 01:20:12', '2025-10-27 01:20:12'),
(197, 'Café Gold Nescafé 100g', 7, 'UNIDAD', 7500.00, 20.000, 'Frasco vidrio', 1, '2025-10-27 01:20:12', '2025-10-27 01:20:12'),
(198, 'Pan Pita Integral 6un', 2, 'UNIDAD', 2400.00, 30.000, 'Bolsa panadería', 1, '2025-10-27 01:20:12', '2025-10-27 01:20:12'),
(199, 'Porotos Granados 1kg', 7, 'UNIDAD', 2800.00, 40.000, 'Legumbre seca', 1, '2025-10-27 01:20:12', '2025-10-27 01:20:12'),
(200, 'Helado Vegano NotCo 1L', 5, 'UNIDAD', 5800.00, 20.000, 'Chocolate y almendra', 1, '2025-10-27 01:20:12', '2025-10-27 01:20:12');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE `usuarios` (
  `id_usuario` int(11) NOT NULL,
  `username` varchar(60) NOT NULL,
  `password` varchar(255) NOT NULL,
  `rol` enum('ADMIN','VENDEDOR') NOT NULL DEFAULT 'VENDEDOR',
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id_usuario`, `username`, `password`, `rol`, `activo`, `created_at`) VALUES
(1, 'admin', 'admi10_app', 'ADMIN', 1, '2025-10-27 01:06:27'),
(2, 'vendedor', 'ventas2025', 'VENDEDOR', 1, '2025-10-27 01:06:27');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ventas`
--

DROP TABLE IF EXISTS `ventas`;
CREATE TABLE `ventas` (
  `id_venta` int(11) NOT NULL,
  `fecha` datetime NOT NULL DEFAULT current_timestamp(),
  `subtotal` decimal(12,2) NOT NULL DEFAULT 0.00,
  `iva` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_final` decimal(12,2) NOT NULL DEFAULT 0.00,
  `id_usuario` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `ventas`
--

INSERT INTO `ventas` (`id_venta`, `fecha`, `subtotal`, `iva`, `total_final`, `id_usuario`, `created_at`, `updated_at`) VALUES
(1, '2025-10-27 17:27:07', 3850.00, 731.50, 4581.50, 2, '2025-10-27 20:27:07', '2025-10-27 20:27:07'),
(2, '2025-10-27 18:13:47', 7800.00, 1482.00, 9282.00, 2, '2025-10-27 21:13:47', '2025-10-27 21:13:47'),
(3, '2025-10-27 19:14:23', 850.00, 161.50, 1011.50, 2, '2025-10-27 22:14:23', '2025-10-27 22:14:23');

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_reporte_ventas`
-- (Véase abajo para la vista actual)
--
DROP VIEW IF EXISTS `vista_reporte_ventas`;
CREATE TABLE `vista_reporte_ventas` (
`id_venta` int(11)
,`fecha` datetime
,`usuario` varchar(60)
,`subtotal` decimal(11,0)
,`iva` decimal(11,0)
,`total_final` decimal(11,0)
);

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_reporte_ventas`
--
DROP TABLE IF EXISTS `vista_reporte_ventas`;

DROP VIEW IF EXISTS `vista_reporte_ventas`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_reporte_ventas`  AS SELECT `v`.`id_venta` AS `id_venta`, `v`.`fecha` AS `fecha`, `u`.`username` AS `usuario`, round(`v`.`subtotal`,0) AS `subtotal`, round(`v`.`iva`,0) AS `iva`, round(`v`.`total_final`,0) AS `total_final` FROM (`ventas` `v` join `usuarios` `u` on(`v`.`id_usuario` = `u`.`id_usuario`)) ORDER BY `v`.`fecha` DESC ;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id_categoria`),
  ADD UNIQUE KEY `nombre` (`nombre`);

--
-- Indices de la tabla `detalle_venta`
--
ALTER TABLE `detalle_venta`
  ADD PRIMARY KEY (`id_detalle`),
  ADD KEY `fk_det_venta` (`id_venta`),
  ADD KEY `fk_det_producto` (`id_producto`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id_producto`),
  ADD KEY `fk_prod_cat` (`id_categoria`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_usuario`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indices de la tabla `ventas`
--
ALTER TABLE `ventas`
  ADD PRIMARY KEY (`id_venta`),
  ADD KEY `fk_venta_usuario` (`id_usuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id_categoria` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `detalle_venta`
--
ALTER TABLE `detalle_venta`
  MODIFY `id_detalle` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `id_producto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=201;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `ventas`
--
ALTER TABLE `ventas`
  MODIFY `id_venta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `detalle_venta`
--
ALTER TABLE `detalle_venta`
  ADD CONSTRAINT `fk_det_producto` FOREIGN KEY (`id_producto`) REFERENCES `productos` (`id_producto`),
  ADD CONSTRAINT `fk_det_venta` FOREIGN KEY (`id_venta`) REFERENCES `ventas` (`id_venta`) ON DELETE CASCADE;

--
-- Filtros para la tabla `productos`
--
ALTER TABLE `productos`
  ADD CONSTRAINT `fk_prod_cat` FOREIGN KEY (`id_categoria`) REFERENCES `categorias` (`id_categoria`);

--
-- Filtros para la tabla `ventas`
--
ALTER TABLE `ventas`
  ADD CONSTRAINT `fk_venta_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`);


--
-- Metadatos
--
USE `phpmyadmin`;

--
-- Metadatos para la tabla categorias
--

--
-- Volcado de datos para la tabla `pma__table_uiprefs`
--

INSERT INTO `pma__table_uiprefs` (`username`, `db_name`, `table_name`, `prefs`, `last_update`) VALUES
('root', 'minimarket_db', 'categorias', '{\"sorted_col\":\"`id_categoria` ASC\"}', '2025-10-27 19:24:54');

--
-- Metadatos para la tabla detalle_venta
--

--
-- Metadatos para la tabla productos
--

--
-- Volcado de datos para la tabla `pma__table_uiprefs`
--

INSERT INTO `pma__table_uiprefs` (`username`, `db_name`, `table_name`, `prefs`, `last_update`) VALUES
('root', 'minimarket_db', 'productos', '{\"sorted_col\":\"`productos`.`id_producto` ASC\"}', '2025-10-27 01:16:10');

--
-- Metadatos para la tabla usuarios
--

--
-- Metadatos para la tabla ventas
--

--
-- Metadatos para la tabla vista_reporte_ventas
--

--
-- Metadatos para la base de datos minimarket_db
--

--
-- Volcado de datos para la tabla `pma__pdf_pages`
--

INSERT INTO `pma__pdf_pages` (`db_name`, `page_descr`) VALUES
('minimarket_db', 'minimarketViewTable');

SET @LAST_PAGE = LAST_INSERT_ID();

--
-- Volcado de datos para la tabla `pma__table_coords`
--

INSERT INTO `pma__table_coords` (`db_name`, `table_name`, `pdf_page_number`, `x`, `y`) VALUES
('minimarket_db', 'categorias', @LAST_PAGE, 627, 56),
('minimarket_db', 'detalle_venta', @LAST_PAGE, 357, 355),
('minimarket_db', 'productos', @LAST_PAGE, 348, 52),
('minimarket_db', 'usuarios', @LAST_PAGE, 65, 55),
('minimarket_db', 'ventas', @LAST_PAGE, 68, 325);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
